import java.util.Arrays;
import java.util.List;

public class Mostro {
    private String tipo;
    private String nome;
    private int vita;
    private final List<Mossa> mosse;

    public Mostro(String nome, String tipo, int vita, Mossa... mosse) {
        this.tipo = tipo;
        this.nome = nome;
        this.vita = vita;
        this.mosse = Arrays.asList(mosse);
    }

    public String getTipo() {
        return tipo;
    }

    public String getNome() {
        return nome;
    }

    public int getVita() {
        return vita;
    }

    public void setVita(int vita) {
        this.vita = vita;
    }

    public List<Mossa> getMosse() {
        return mosse;
    }

    public boolean isAlive() {
        return vita > 0;
    }

    public void displayMoves() {
        for (int i = 0; i < mosse.size(); i++) {
            System.out.println((i + 1) + ". " + mosse.get(i).getNome() + " (Danno: " + mosse.get(i).getDanno() + ", Utilizzi: " + mosse.get(i).getUtilizzi() + ")");
        }
    }

    public void useMove( int indice, Mostro nemico) {

        Mossa selectedMove = mosse.get(indice);
        int damage = selectedMove.getDanno();

        if (selectedMove.getUtilizzi() > 0) {
           selectedMove.setUtilizzi(selectedMove.getUtilizzi()-1);
        if (damage > 0) {
            nemico.vita -= damage;
        if (nemico.vita > 0) {
            System.out.println(nome + " usa " + selectedMove.getNome() + "! Procura " + damage + " danni a " + nemico.getNome() + ". (A " + nemico.getNome() + " restano: " + nemico.vita + " HP)");
        } else if (nemico.vita <= 0) {
            System.out.println(nome + " usa " + selectedMove.getNome() + "! Procura " + damage + " danni a " + nemico.getNome() + ". " + nemico.getNome() + " è caduto: 0 HP");
        }
        } else {
        vita -= damage; // Healing is negative damage
        System.out.println(nome + " usa " + selectedMove.getNome() + "! Si cura di " + (-damage) + " HP. (A " + nome + " restano: " + vita + " HP)");
        }

        }else{
            System.out.println("Utilizzi mossa terminati! perdi il turno!");
        }
    }

    public List<Mossa> getMoves() {
        return mosse;
    }
}

