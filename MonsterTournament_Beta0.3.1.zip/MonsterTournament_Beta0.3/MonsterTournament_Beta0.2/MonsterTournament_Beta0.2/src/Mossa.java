public class Mossa {
    private String nome;
    private int danno;
    private int utilizzi;

    public Mossa(String nome, int danno, int utilizzi) {
        this.nome = nome;
        this.danno = danno;
        this.utilizzi = utilizzi;
    }

    public String getNome() {
        return nome;
    }

    public int getDanno() {
        return danno;
    }

    public int getUtilizzi() {
        return utilizzi;
    }

    public void setUtilizzi(int utilizzi) {
        this.utilizzi = utilizzi;
    }
}
