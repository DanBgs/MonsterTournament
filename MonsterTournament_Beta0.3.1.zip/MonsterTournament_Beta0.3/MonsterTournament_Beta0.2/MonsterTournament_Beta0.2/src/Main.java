//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
        public static void main(String Args[]){
            Game g1 = new Game();
            Torneo t1 = new Torneo();
            g1.start1v1Battle(t1);
        }
}