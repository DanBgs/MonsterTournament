import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Game {
    private List<Mostro> monsters = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public Game() {
        initializeMonsters();
    }

    private void initializeMonsters() {
        monsters.add(new Mostro("Nara", "Donna Cuculo", 1100, new Mossa("Ali taglienti",150, 15), new Mossa("Soffio vitale",-300, 5), new Mossa("Richiamo sonico",80, 15)));
        monsters.add(new Mostro("Maximus", "Pegaso", 1450, new Mossa("Fulmine di Pegaso", 150, 10), new Mossa("Colpo celeste",200, 10), new Mossa("Aura lucente",-500, 3)));
        monsters.add(new Mostro("Soar", "Fenice", 2000, new Mossa("Fiamma rinascente", -500, 4), new Mossa("Raggio Ardente",180, 10), new Mossa("Canto infuocato",80, 15)));
        monsters.add(new Mostro("Aestades", "Centauro", 1500, new Mossa("Carica furiosa", 300, 5), new Mossa("Fendente del cavaliere",100, 12), new Mossa("Calpestio furioso",70,15)));
        monsters.add(new Mostro("Sammael", "Cerbero", 1200, new Mossa("Morsa del guardiano", 200, 10), new Mossa("Fiamma infernale",150, 10), new Mossa("Urlo abissale",70, 15)));
        monsters.add(new Mostro("Tuzid", "Chimera", 1400, new Mossa("Fiato di drago", 200, 8), new Mossa("Morso di leone",150, 15), new Mossa("Fuga di capra",-100, 8)));
        monsters.add(new Mostro("Incarnath", "Idra", 1900, new Mossa("Moltiplicazione letale", 300, 5), new Mossa("Soffio corrosivo",150, 10), new Mossa("Attacco a tre teste",180, 10)));
        monsters.add(new Mostro("Rex", "Basilisco", 1600, new Mossa("Sguardo pietrificante", 300, 5), new Mossa("Assorbimento velenoso",-150,5), new Mossa("Lacerazione di zanna",150, 15)));
        monsters.add(new Mostro("Aldebaran", "Minotauro", 1800, new Mossa("Carica del Labirinto", 200, 10), new Mossa("Luce del Toro",-180, 5), new Mossa("Ruggito domatore",100, 15)));
        monsters.add(new Mostro("Jurgandr", "Kraken", 1950, new Mossa("Stritolamento letale", 200, 10), new Mossa("Mare Infausto",-100, 8), new Mossa("Colpo di Tentacolo",180, 10)));
        monsters.add(new Mostro("Aspidus", "Balena Isola", 2000, new Mossa("Tsunami abissale", 300, 5), new Mossa("Corazza marina",-80, 5), new Mossa("Sciabordio marino",100, 15)));
        monsters.add(new Mostro("Tishtar", "Sirena", 1000, new Mossa("Canto ipnotico", 150, 15), new Mossa("Aiuto del fondale",-300, 5), new Mossa("Incanto della marea",150, 15)));
    }

    public void start1v1Battle(Torneo t1) {
        List<Mostro> avversari = new ArrayList();
        List<Mostro> backupMostri = new ArrayList();
        for (int i = 0; i < monsters.size(); i++) {
            System.out.println((i + 1) + ". " + monsters.get(i).getTipo() + " " + monsters.get(i).getNome());
        }
        System.out.println("Seleziona il tuo mostro: ");
        for (int i=0;i<monsters.size();i++) {
            backupMostri.add(monsters.get(i));
        }
        int playerChoice = scanner.nextInt() - 1;
        Mostro player1 = backupMostri.get(playerChoice);
        backupMostri.remove(playerChoice);
        avversari = t1.Sfidanti(backupMostri);
       // Mostro opponentMonster = monsters.get(new Random().nextInt(monsters.size()));


               System.out.println("Benvenuto!! Inizia il torneo dei Mostri");
           System.out.println("Giocatore 1: " + player1.getNome());
           System.out.println(avversari.get(0).getTipo() + " "+ avversari.get(0).getNome()+ " sarà il tuo avversario");
           if(battle(player1, avversari.get(0))){
               System.out.println("Complimenti, sei passato alla prossiam fase!! le semifinali");
           }else{
               System.out.println("Peccato, per te è finita XoX");
               return;
           }
        //initializeMonsters();
        //player1 = monsters.get(playerChoice);
            System.out.println(avversari.get(0).getTipo() + " "+ avversari.get(0).getNome()+ " sarà il tuo avversario");
        if(battle(player1, avversari.get(1))){
            System.out.println("Complimenti, sei passato alla prossiam fase!! le finali");
        }else{
            System.out.println("Peccato, per te è finita XoX");
            return;
        }
        //initializeMonsters();
        //player1 = monsters.get(playerChoice);
        System.out.println(avversari.get(0).getTipo() + " "+ avversari.get(0).getNome()+ " sarà il tuo avversario");
        if(battle(player1, avversari.get(1))){
            System.out.println("Complimenti, sei il CAMPIONE del torneo dei Mostri!!");
        }else{
            System.out.println("Peccato, hai perso il torneo XoX");
        }


    }

    private boolean battle(Mostro player, Mostro opponent) {
        Boolean E=true;
        int[] utilizzi = new int[3];
        int vita=player.getVita();
        for (int i = 0; i<player.getMosse().size();i++) {
            utilizzi[i] = player.getMosse().get(i).getUtilizzi();
        }
        System.out.println("\nInizia la battaglia!");

        while (player.isAlive() && opponent.isAlive()) {
            System.out.println("\nTocca a te! Scegli una mossa:");
            player.displayMoves();
            int moveChoice = 0;
           do {
               moveChoice = scanner.nextInt() - 1;
               if (moveChoice < 0 || moveChoice >= 3) {
                   System.out.println("Mossa invalida! riprova");
               }
           }while(moveChoice < 0 || moveChoice >= 3);
            player.useMove(moveChoice, opponent);

            if (opponent.isAlive()) {
                System.out.println("\nTocca a " + opponent.getNome() +"!");
                int opponentMoveChoice = new Random().nextInt(opponent.getMoves().size());
                opponent.useMove(opponentMoveChoice, player);
            }
        }

        if (player.isAlive()) {
            System.out.println("\nHai vinto!");
            player.setVita(vita);
            for (int i = 0; i<player.getMosse().size();i++) {
                player.getMosse().get(i).setUtilizzi(utilizzi[i]);
            }
        } else {
            System.out.println("\nHai perso! La prossima volta andra meglio!");
            E=false;
        }
        return E;
    }

}

