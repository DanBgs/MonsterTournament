import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Collections;
public class Torneo {
    public Torneo() {
    }

    public static List<String> generaLista(List<Mostro> g1){
        List<String> lista = new ArrayList<>();
        Random rand = new Random();
        List<String> indices = new ArrayList<>();
        for (int i=0; i<g1.size(); i++) {
            lista.add(String.valueOf(i));
        }
        do {
            int r1 = rand.nextInt(0, lista.size());
            int r2 = rand.nextInt(0, lista.size());
            int r3 = rand.nextInt(0, lista.size());
            int r4 = rand.nextInt(0, lista.size());
            while (r1 == r2) {
                r2 = rand.nextInt(lista.size());
            }while (r2 == r3) {
                r3 = rand.nextInt(lista.size());
            }while (r1 == r3) {
                r3 = rand.nextInt(lista.size());
            }while (r2 == r4) {
                r4 = rand.nextInt(lista.size());
            }while (r1 == r4) {
                r4 = rand.nextInt(lista.size());
            }while (r4 == r3) {
                r4 = rand.nextInt(lista.size());
            }

                indices.add(String.valueOf(r1));
                indices.add(String.valueOf(r2));
                indices.add(String.valueOf(r3));
                indices.add(String.valueOf(r4));
                Collections.sort(indices);


        }while(indices.size()<4);
        for(int i=0;i<indices.size();i++){
            for(int j=0; j<lista.size();j++){
                if(lista.get(j).equals(indices.get(i))){
                    lista.remove(j);
                }
            }
        }

        return lista;
    }
    public static List<Mostro>Sfidanti(List<Mostro> partecipanti){
        Random rand = new Random();
        List<Mostro> lista = new ArrayList<>();
        do{
            int r1 = rand.nextInt(0, partecipanti.size());
            lista.add(partecipanti.get(r1));

        }while(lista.size()<3);
        return lista;
    }
}
